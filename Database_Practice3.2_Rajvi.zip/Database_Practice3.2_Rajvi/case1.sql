 create table `section3.2`.`activity`(
 `playerId` int not null ,
 `deviceId` int not null,
 `eventDate` date not null ,
 `gamesPlayed` int not null,
 primary key(`playerId` ,`eventDate`)
);
insert into `section3.2`.`activity`(`playerId`,`deviceId`, `eventDate`, `gamesPlayed`)value(1,2,'2016-03-01',5);
insert into `section3.2`.`activity`(`playerId`,`deviceId`, `eventDate`, `gamesPlayed`)value(1,2,'2016-05-02',6);
insert into `section3.2`.`activity`(`playerId`,`deviceId`, `eventDate`, `gamesPlayed`)value(2,3,'2017-06-25',1);
insert into `section3.2`.`activity`(`playerId`,`deviceId`, `eventDate`, `gamesPlayed`)value(3,1,'2016-03-02',0);
insert into `section3.2`.`activity`(`playerId`,`deviceId`, `eventDate`, `gamesPlayed`)value(3,4,'2018-07-03',5);


select playerId, min(eventDate) as first_login
from `section3.2`.`activity`
group by playerId;

select playerId, deviceId  
from `section3.2`.`activity`
group by playerId;


select a.playerId, a.deviceId
from `section3.2`.`activity` a JOIN
(select playerId, min(eventDate) 'first_login'
from `section3.2`.`activity` group by playerId) t
ON a.playerId=t.playerId and a.eventDate = t.first_login;

select playerId, eventDate, sum(gamesPlayed) over(partition by playerId order by eventDate) 'games_played_so_far'
from `section3.2`.`activity` 






