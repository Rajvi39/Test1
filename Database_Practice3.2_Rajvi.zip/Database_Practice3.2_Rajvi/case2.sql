create table`section3.2`.`course`(
`student` varchar(48) not null ,
`class` varchar(32) not null,
primary key(`student`,`class`)
);

insert into `section3.2`.`course`(`student`,`class`)value('A','math');
insert into `section3.2`.`course`(`student`,`class`)value('B','english');
insert into `section3.2`.`course`(`student`,`class`)value('c','math');
insert into `section3.2`.`course`(`student`,`class`)value('D','biology');
insert into `section3.2`.`course`(`student`,`class`)value('E','math');
insert into `section3.2`.`course`(`student`,`class`)value('F','computer');
insert into `section3.2`.`course`(`student`,`class`)value('G','math');
insert into `section3.2`.`course`(`student`,`class`)value('H','math');
insert into `section3.2`.`course`(`student`,`class`)value('I','math');


select `course`.`class`
from `section3.2`.`course`
group by class having count(distinct student) > 5;