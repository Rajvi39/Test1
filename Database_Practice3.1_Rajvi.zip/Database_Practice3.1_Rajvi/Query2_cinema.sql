create table  `databasetest`.`cinema`(
`id` int not null auto_increment,
`movie` varchar(48) not null,
`description` varchar(48) not null,
`rating` float(10,2) not null,
primary key(`id`)
);

INSERT INTO `databasetest`.`cinema`(`movie`,`description`,`rating`)
values ('war','great 3D',8.9);

INSERT INTO `databasetest`.`cinema`(`movie`,`description`,`rating`)
values (' Science','fiction',8.5);

INSERT INTO `databasetest`.`cinema`(`movie`,`description`,`rating`)
values ('irish','boring',6.2);

INSERT INTO `databasetest`.`cinema`(`movie`,`description`,`rating`)
values ('Ice song','Fantacy',8.6);

INSERT INTO `databasetest`.`cinema`(`movie`,`description`,`rating`)
values ('House card','Interesting',9.1);

select * from `databasetest`.`cinema`
where mod(id,2)!=0 and description!='boring'
order by rating desc;



