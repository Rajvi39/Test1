create table `databasetest`.`person1`(
`personId` int not null auto_increment,
`lastName` varchar(48) not null ,
`firstName` varchar(48) not null ,
primary key(`personId`)
);

create table `databasetest`.`address`(
`addressId` int not null auto_increment,
`personId`  int not null ,
`city` varchar(48) not null,
`state` varchar(48) not null,
primary key(`addressId`),
Foreign key(`personId`) references `databasetest`.`person1`(`personId`)
);

insert into `databasetest`.`person1` (`lastName`,`firstName`)values('Wang','Allen');
insert into `databasetest`.`person1` (`lastName`,`firstName`)values('Alice','Bob');
insert into `databasetest`.`person1` (`lastName`,`firstName`)values('Rajvi','Sathvara');


insert into `databasetest`.`address` (`personId`,`city`,`state`)values(1,'New York City','New York');
insert into `databasetest`.`address` (`personId`,`city`,`state`)values(2,'Leetcode','California');

SELECT person1.personId, person1.lastName, person1.firstName,address.city, address.state
FROM `databasetest`.`address`
RIGHT JOIN `databasetest`.`person1` ON person1.personId = address.addressId ;



