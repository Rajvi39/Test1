create table `databasetest`.`salary`(
`id` int not null auto_increment,
`name` varchar(32) not null,
`sex` enum('f','m') not null,
`salary` float not null,
primary key(`id`)
);

INSERT INTO `databasetest`.`salary`(`name`,`sex`,`salary`)
values ('A','m',2500);
INSERT INTO `databasetest`.`salary`(`name`,`sex`,`salary`)
values ('B','f',1500);
INSERT INTO `databasetest`.`salary`(`name`,`sex`,`salary`)
values ('C','m',5500);
INSERT INTO `databasetest`.`salary`(`name`,`sex`,`salary`)
values ('D','f',500);

update `databasetest`.`salary`
set sex=if(sex='m','f','m');
