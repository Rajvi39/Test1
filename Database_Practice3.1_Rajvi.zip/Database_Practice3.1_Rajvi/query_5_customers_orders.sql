create table `databasetest`.`customers`(
`id` int not null auto_increment,
`name` varchar(48) not null ,
primary key(`id`)
);
create table `databasetest`.`orders`(
`id` int not null auto_increment,
`customerId`  int not null ,
primary key(`id`),
Foreign key(`customerId`) references `databasetest`.`customers`(`id`)
);

INSERT INTO `databasetest`.`customers`(`name`)values('Joe');
INSERT INTO `databasetest`.`customers`(`name`)values('Henry');
INSERT INTO `databasetest`.`customers`(`name`)values('Sam');
INSERT INTO `databasetest`.`customers`(`name`)values('Max');

INSERT INTO `databasetest`.`orders`(`customerId`)values('3');
INSERT INTO `databasetest`.`orders`(`customerId`)values('1');

select `name` from `databasetest`.`customers`
where `id` not in(select `customerId` from `databasetest`.`orders`);



