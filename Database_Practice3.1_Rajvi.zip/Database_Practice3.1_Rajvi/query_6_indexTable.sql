create table `databasetest`.`indexTable`(
`id` int not null auto_increment,
`email` varchar(48) not null ,
primary key(`id`)
);

CREATE INDEX index_name
ON `databasetest`.`indexTable`(email);

show index from `databasetest`.`indexTable`;