create table `databasetest`.`person`(
`id` int not null auto_increment,
`email` varchar(48) not null ,
primary key(`id`)
);

INSERT INTO `databasetest`.`person`(`email`)values('john@example.com');
INSERT INTO `databasetest`.`person`(`email`)values('bob@example.com');
INSERT INTO `databasetest`.`person`(`email`)values('john@example.com');

delete from `databasetest`.`person` where id not in (select * from (select min(id)
 from `databasetest`.`person` group by email) as p);
select * from `databasetest`.`person`;
