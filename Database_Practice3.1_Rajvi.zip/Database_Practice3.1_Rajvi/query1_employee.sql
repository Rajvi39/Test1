CREATE table `databasetest`.`employee`(
`empID` INT NOT NULL AUTO_INCREMENT,
`empName`varchar(48)NOT NULL,
`empDob`date NOT NULL,
`empGender`varchar(8) NOT NULL,
`empJoinDate`date NOT NULL,
`empPhoneNum` varchar(16) NOT NULL, 
`empSalary` double NOT NULL,
PRIMARY KEY (`empId`));

CREATE table `databasetest`.`department`(
`empID` INT NOT NULL,
`depID` INT NOT NULL AUTO_INCREMENT,
`depName`varchar(48)NOT NULL,
`designation` varchar(16)NOT NULL,
FOREIGN KEY (`empID`) REFERENCES `databasetest`.`employee`(`empID`),
PRIMARY KEY (`depID`)
);
CREATE table `databasetest`.`leave`(
`leaveID` INT NOT NULL,
`empID` INT NOT NULL,
`depID` INT NOT NULL,
`leaveStartDate` date NOT NULL ,
`leaveEndDate` date NOT NULL ,
`leaveType` varchar(48) NOT NULL,
FOREIGN KEY (`empID`) REFERENCES `databasetest`.`employee`(`empID`),
FOREIGN KEY (`depID`) REFERENCES `databasetest`.`department`(`depID`),
PRIMARY KEY (`leaveID`)
);