create schema `student`;

CREATE TABLE `student`.`semesterMaster` (
    `id` INT NOT NULL AUTO_INCREMENT,
    `semNo` INT NOT NULL,
    PRIMARY KEY (id)
);
create table `student`.`subjectMaster`(
`id` int not null auto_increment,
`subjectName` varchar(16) not null,
primary key(`id`)
);

create table `student`.`StudentGrade`(
`rollNo` int not null auto_increment,
`name` varchar(48) not null,
`dob` date not null,
`semId` int not null,
`subId` int not null,
`grade` varchar(8) not null,
primary key (`rollNo`),
Foreign key(`semId`) references `student`.`semesterMAster`(`id`),
Foreign key(`subId`) references `student`.`subjectMAster`(`id`)
 );
 
 