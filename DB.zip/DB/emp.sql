CREATE table `databasetest`.`employee`(
`empID` INT NOT NULL AUTO_INCREMENT,
`empName`varchar(48)NOT NULL,
`empDob`date NOT NULL,
`empGender`varchar(8) NOT NULL,
`empJoinDate`date NOT NULL,
`empPhoneNum` varchar(16) NOT NULL, 
`empSalary` double NOT NULL,
PRIMARY KEY (`empId`));
