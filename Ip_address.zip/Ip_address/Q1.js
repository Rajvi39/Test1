//console.log("Ajax Application");
function search(){
    console.log('You have clicked the button');
    var req=new XMLHttpRequest();

var inputtedIP = document.getElementById("input1").value;
if(inputtedIP==""){
    alert("Please Enter IP Address");
    return false;
}
var apiURL = "https://ipinfo.io/" + inputtedIP  +"/geo"

req.open("GET",apiURL ,true);

req.onload=function(){
    if(this.status==200)
    {
        //alert("hii");
        var obj=this.responseText;
         if(obj){
           // alert("hlo");
             obj=JSON.parse(this.responseText);
             if(obj.bogon==true){
                alert("Bogon IP Address...");
                document.getElementById('input1').value = "";
                 return false;
                 }
            else{
                document.getElementById('input1').value = "";
                var tbl=document.getElementById("table1");
                console.log(obj);
                var r1=tbl.insertRow();
                var r2=tbl.insertRow();
                var r3=tbl.insertRow();
                var r4=tbl.insertRow();

                var cell1=r1.insertCell();
                var cell2=r1.insertCell();
                var cell3=r2.insertCell();
                var cell4=r2.insertCell();
                var cell5=r3.insertCell();
                var cell6=r3.insertCell();
                var cell7=r4.insertCell();
                var cell8=r4.insertCell();
                cell1.innerHTML="ip";
                cell2.innerHTML=obj.ip;
                cell3.innerHTML="City";
                cell4.innerHTML=obj.city;
                cell5.innerHTML="Region";
                cell6.innerHTML=obj.region;
                cell7.innerHTML="Country";
                cell8.innerHTML=obj.country;
             }
        }   
    }
    else{
        alert("Error:Plase Enter Proper Valid IP Address!!");
        document.getElementById('input1').value = "";
        console.log("error");
        return false;
    }
}
document. getElementById("table1"). innerHTML="";
req.send();
}