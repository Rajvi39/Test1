#1. List out all questions with it’s answer which is having maximum vote.(Done)
    select title,poll_answer.pollId,poll_vote.content,max(answerId_vote) from poll.poll,poll.poll_answer,poll.poll_vote
	group by (`answerId_vote`);

#2. List out all the categories which is having multiple poll questions under it.(Done)

    SELECT `poll_question`.`type`, `poll`.`title` FROM poll.poll_question
    inner join poll.poll
	on `poll_question`.`pollId`=`poll`.`id`
    where poll_question.type='Multiple Choice';

#3. List out all the polls which are currently active.(Done)
    SELECT poll.title,active FROM `poll`.`poll_answer`
	inner join poll.poll
    where active=1 and poll.id=poll_answer.pollId;
    
#4. List out all the users who is not logged in since last week.(Done)

      SELECT `user`.`id`,`user`.`firstName`, `user`.`lastLogin`
	  FROM `poll`.`user` 
	  WHERE lastLogin  BETWEEN  NOW() - INTERVAL 7 DAY AND NOW()
	  GROUP BY(id);
  
#5. List out all the users whose email provider is not google.(DONE)
SELECT firstName,email FROM`poll`.`user` 
WHERE email not LIKE '%gmail.com';

#6. List out all the polls which are published in 2021.(Done)
SELECT publishedAt FROM`poll`.`poll`
WHERE publishedAt LIKE '%2021%';

#7. List out all the users who did not answer any poll yet.
	SELECT `user`.`firstName`,`poll_answer`.`pollId`,`poll_answer`.`questionId`
	FROM   `poll`.`user`,`poll`.`poll_answer`
    INNER JOIN
		   `poll`.`poll`
    WHERE  `poll_answer`.`pollID`= `poll`.`id`
    order by (firstName);
    
-- INNER JOIN
-- 		   `poll`.`poll` 
-- 	where   `poll`.`id` = `poll_answer`.`pollID`;
-- 	#WHERE  `poll_answer`.`pollID`!= `poll`.`id`;

#8. Create all the possible unique key and indexes for this database schema.
	CREATE UNIQUE INDEX uid
	ON `poll`.`user` (id);












