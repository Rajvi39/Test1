#Q1. Total income of Restaurant till now.
SELECT SUM(`grandTotal`) as Total_income
FROM `test`.`order`;

#Q2. Customer who visited the restaurant more than twice.
select `firstName`,  count(`userId1`) as  more_than_twice
from `test`.`order`
group by (`userId1`)
having count(`userId1`)>=2;

#Q3. List of all menus with its menu items.
select `menu`.`title` as MainMenu,`item`.`title` as SubMenu
from `test`.`menu`,`test`.`item`
inner join `test`.`menu_item`
where `menu`.`id`=`menu_item`.`menuId` and `menu_item`.`itemId`=`item`.`id`;

#4. List out all the unique ids and possible indexes for this DB schema.


#Q5. List out total order placed by each User.
select `firstName`,count(`userId1`) as PlacedOrder
from `test`.`order`
group by (`userId1`)
having count(`userId1`);

#6. Make a list of each user and the highest-priced menu item he or she ordered.
select firstName,max(grandTotal) as highest_price
from test.order
group by (firstName);

#7. Retrieve the name of a chef who prepares more recipes than any other chef. 
select chefName,count(chefId) as ma
from `test`.`chef`,`test`.`item_chef`
where `chef`.`id`=`item_chef`.`chefId`
group by(chefName)
order by ma desc
limit 1;


#8. Retrieve the amount of subtotal for all day on 9th November 2021. (It does not include the total, formula: item price * ordered qty).
select `subTotal`,`createdAt` from test.order
where createdAt like '%2021-11-09%';


#Q9. List out user along with the average amount spend at the  restaurant.
select `firstName`,avg(`grandTotal`) as averageAmount
from `test`.`order`
group by (`firstName`);

#10.List out the menu items which are preferred by the customer at dinner time.
  select title
  from `test`.`item`
  inner join `test`.`order_item`
  where order_item.itemIdOrder_item=item.id and HOUR(order_item.createdAt)>18; 
