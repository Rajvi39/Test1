<!DOCTYPE html>
<html>
    <head>
        <title></title>

    </head>
    <script type="text/javascript" > 
    async function add_tea() {
        
    }

async function add_tea() {
  let tea = new Promise(function(resolve) {
    setTimeout(function() {resolve("add_tea");}, 3000);
  });
  document.getElementById("demo").innerHTML = await tea;
}

add_tea();
async function add_milk() {
  let milk = new Promise(function(resolve) {
    setTimeout(function() {resolve("add_milk");}, 3000);
  });
  document.getElementById("demo").innerHTML = await milk;
}

add_milk();

</script>
<body>

<h2>JavaScript async / await</h2>

<p>Wait 3 seconds (3000 milliseconds) for this page to change.</p>

<h1 id="demo"></h1>



</body>
</html>
